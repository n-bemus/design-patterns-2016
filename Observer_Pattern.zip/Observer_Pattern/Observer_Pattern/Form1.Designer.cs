﻿namespace Observer_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenForm = new System.Windows.Forms.Button();
            this.lblGameUpateTitle = new System.Windows.Forms.Label();
            this.tbxGameUpdate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnOpenForm
            // 
            this.btnOpenForm.Location = new System.Drawing.Point(117, 12);
            this.btnOpenForm.Name = "btnOpenForm";
            this.btnOpenForm.Size = new System.Drawing.Size(174, 46);
            this.btnOpenForm.TabIndex = 0;
            this.btnOpenForm.Text = "Open Report Guide";
            this.btnOpenForm.UseVisualStyleBackColor = true;
            this.btnOpenForm.Click += new System.EventHandler(this.btnOpenForm_Click);
            // 
            // lblGameUpateTitle
            // 
            this.lblGameUpateTitle.AutoSize = true;
            this.lblGameUpateTitle.Location = new System.Drawing.Point(26, 70);
            this.lblGameUpateTitle.Name = "lblGameUpateTitle";
            this.lblGameUpateTitle.Size = new System.Drawing.Size(96, 17);
            this.lblGameUpateTitle.TabIndex = 1;
            this.lblGameUpateTitle.Text = "Game Update";
            // 
            // tbxGameUpdate
            // 
            this.tbxGameUpdate.Location = new System.Drawing.Point(29, 138);
            this.tbxGameUpdate.Name = "tbxGameUpdate";
            this.tbxGameUpdate.Size = new System.Drawing.Size(302, 22);
            this.tbxGameUpdate.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 303);
            this.Controls.Add(this.tbxGameUpdate);
            this.Controls.Add(this.lblGameUpateTitle);
            this.Controls.Add(this.btnOpenForm);
            this.Name = "Form1";
            this.Text = "Game Score";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenForm;
        private System.Windows.Forms.Label lblGameUpateTitle;
        private System.Windows.Forms.TextBox tbxGameUpdate;
    }
}

