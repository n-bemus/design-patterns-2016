﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer_Pattern
{
    public partial class Form2 : Form
    {

        public string _Slayer;
        public string _Slain;
        //private bool _isTeamOne;

        public delegate void UpdateScoreEventHandler(object sender, ScoreUpdateEventArgs e);

        //public event UpdateScoreEventHandler ScoreUpdated;
        public event UpdateScoreEventHandler UpdateSlay;

        //public string Slayer
        //{
        //    get { return _Slayer; }
        //    set { _Slayer = value; }
        //}

        //public string Slain
        //{
        //    get { return _Slain; }
        //    set { _Slain = value; }
        //}

        //public bool isTeamOne
        //{
        //    get { return _isTeamOne; }
        //    set { _isTeamOne = value; }
        //}

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(string Slayer, string Slain)
        {
            InitializeComponent();
            Slayer = _Slayer;
            Slain = _Slain;
            //isTeamOne = _isTeamOne;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            UpdateSlay(this, new ScoreUpdateEventArgs(tbxSlayer.Text, tbxSlain.Text));
        }

        //private void Form2_Load(object sender, EventArgs e)
        //{
        //    tbxSlayer.Text = Slayer;
        //    tbxSlain.Text = Slain;
        //}
    }

    public class ScoreUpdateEventArgs : EventArgs
    {
        private string _Slayer;
        private string _Slain;

        public string Slayer
        {
            get { return _Slayer; }
            set { _Slayer = value; }
        }

        public string Slain
        {
            get { return _Slain; }
            set { _Slain = value; }
        }

        public ScoreUpdateEventArgs(string Slayer, string Slain)
        {
            _Slayer = Slayer;
            _Slain = Slain;
        }
    }
}
