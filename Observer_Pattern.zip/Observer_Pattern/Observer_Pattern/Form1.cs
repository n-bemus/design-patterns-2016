﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpenForm_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();

            form2.Location = new Point(this.Location.X + this.Size.Width - 1000, this.Location.Y + this.Size.Height - 1000);

            form2.UpdateSlay += new Form2.UpdateScoreEventHandler(form2_UpdateScoreEvent);
            form2.Show();
        }

        void form2_UpdateScoreEvent(object sender, ScoreUpdateEventArgs e)
        {
            string ScoreUpdateEventString;

            ScoreUpdateEventString = e.Slayer + " has slain the opponent " + e.Slain;

            tbxGameUpdate.Text = "";

            tbxGameUpdate.Text = ScoreUpdateEventString + Environment.NewLine + tbxGameUpdate.Text;
        }


        void form2_UpdateScoreEvent2(object sender, ScoreUpdateEventArgs e)
        {
            this.Text = e.Slayer + " has slain " + e.Slain;
        }
    }
}
