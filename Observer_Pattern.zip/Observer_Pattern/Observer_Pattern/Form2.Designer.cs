﻿namespace Observer_Pattern
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblSlayer = new System.Windows.Forms.Label();
            this.lblSlain = new System.Windows.Forms.Label();
            this.tbxSlayer = new System.Windows.Forms.TextBox();
            this.tbxSlain = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(122, 200);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(191, 23);
            this.btnSubmit.TabIndex = 0;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblSlayer
            // 
            this.lblSlayer.AutoSize = true;
            this.lblSlayer.Location = new System.Drawing.Point(119, 39);
            this.lblSlayer.Name = "lblSlayer";
            this.lblSlayer.Size = new System.Drawing.Size(48, 17);
            this.lblSlayer.TabIndex = 3;
            this.lblSlayer.Text = "Slayer";
            // 
            // lblSlain
            // 
            this.lblSlain.AutoSize = true;
            this.lblSlain.Location = new System.Drawing.Point(259, 39);
            this.lblSlain.Name = "lblSlain";
            this.lblSlain.Size = new System.Drawing.Size(39, 17);
            this.lblSlain.TabIndex = 4;
            this.lblSlain.Text = "Slain";
            // 
            // tbxSlayer
            // 
            this.tbxSlayer.Location = new System.Drawing.Point(27, 104);
            this.tbxSlayer.Name = "tbxSlayer";
            this.tbxSlayer.Size = new System.Drawing.Size(140, 22);
            this.tbxSlayer.TabIndex = 5;
            // 
            // tbxSlain
            // 
            this.tbxSlain.Location = new System.Drawing.Point(262, 104);
            this.tbxSlain.Name = "tbxSlain";
            this.tbxSlain.Size = new System.Drawing.Size(154, 22);
            this.tbxSlain.TabIndex = 6;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 265);
            this.Controls.Add(this.tbxSlain);
            this.Controls.Add(this.tbxSlayer);
            this.Controls.Add(this.lblSlain);
            this.Controls.Add(this.lblSlayer);
            this.Controls.Add(this.btnSubmit);
            this.Name = "Form2";
            this.Text = "Report Guide";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblSlayer;
        private System.Windows.Forms.Label lblSlain;
        private System.Windows.Forms.TextBox tbxSlayer;
        private System.Windows.Forms.TextBox tbxSlain;
    }
}