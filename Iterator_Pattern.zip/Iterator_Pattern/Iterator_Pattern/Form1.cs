﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iterator_Pattern
{
    public partial class Form1 : Form
    {
        Aggregate agg = new ConcreteAggregate();
        Iterator iterator;
        Iterator reverse;

        public Form1()
        {
            InitializeComponent();
            PrepareAggWithIter();
        }

        private void PrepareAggWithIter()
        { 
            agg.Elements.Add("Dave");
            agg.Elements.Add("Tammy");
            agg.Elements.Add("Tyler");
            agg.Elements.Add("Zach");
            agg.Elements.Add("Nathan");
            agg.Elements.Add("Luke");
            iterator = agg.createIterator();
            reverse = agg.createReverseIterator();
        }

        private void btnIterate_Click(object sender, EventArgs e)
        {
            lbCollection.Items.Clear();
            iterator.first();
            while (!iterator.isDone())
            {
                lbCollection.Items.Add(iterator.currItem());
                iterator.next();
            }
        }

        private void btnReverseIterator_Click(object sender, EventArgs e)
        {
            lbCollection.Items.Clear();
            reverse.first();
            while (!reverse.isDone())
            {
                lbCollection.Items.Add(reverse.currItem());
                reverse.next();
            }
        }

        
    }
}
