﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    //This is the Aggregate class
    public abstract class Aggregate
    {
        public List<string> Elements;

        public abstract Iterator createIterator();
        public abstract Iterator createReverseIterator();
    }
}
