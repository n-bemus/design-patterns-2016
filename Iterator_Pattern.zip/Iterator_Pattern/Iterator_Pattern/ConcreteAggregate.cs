﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    //This is the ConcreteAggregate class
    public class ConcreteAggregate : Aggregate
    {
        public ConcreteAggregate()
        {
            Elements = new List<string>();
        }

        public override Iterator createIterator()
        {
            return new ConcreteIterator(this);
        }

        public override Iterator createReverseIterator()
        {
            return new ReverseConcreteIterator(this);
        }
    }
}
