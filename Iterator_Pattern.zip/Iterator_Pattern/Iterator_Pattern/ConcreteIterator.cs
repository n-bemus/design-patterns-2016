﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    public class ConcreteIterator : Iterator
    {
        int CurrIndex;
        Aggregate aggregate;

        public ConcreteIterator(Aggregate agg)
        {
            aggregate = agg;

        }

        public override object first()
        {
            CurrIndex = 0;
            return currItem();
        }

        public override object next()
        {
            if (!isDone())
            {
                CurrIndex++;
            }
            return currItem();
        }

        public override bool isDone()
        {
            return (CurrIndex > aggregate.Elements.Count - 1);
        }

        public override object currItem()
        {
            if (isDone())
            {
                return null;
            }
            return aggregate.Elements[CurrIndex];
        }
    }
}
