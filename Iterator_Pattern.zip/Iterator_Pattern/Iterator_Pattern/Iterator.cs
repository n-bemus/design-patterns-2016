﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    //This is the Iterator class
    public abstract class Iterator 
    {
        public abstract object first();
        public abstract object next();
        public abstract bool isDone();
        public abstract object currItem();
    }
}
