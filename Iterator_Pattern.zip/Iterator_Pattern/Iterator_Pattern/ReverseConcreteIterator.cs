﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    public class ReverseConcreteIterator : Iterator
    {
        int CurrIndex;
        Aggregate ReverseAggregate;

        public ReverseConcreteIterator(Aggregate agg)
        {
            ReverseAggregate = agg;
        }

        public override object first()
        {
            CurrIndex = (ReverseAggregate.Elements.Count - 1);
            return currItem();
        }

        public override object next()
        {
            if (!isDone())
            {
                CurrIndex--;
            }
            return currItem();
        }

        public override bool isDone()
        {
            return CurrIndex < 0;
        }

        public override object currItem()
        {
            if (isDone())
            {
                return null;
            }
            return ReverseAggregate.Elements[CurrIndex];
        }
    }
}
