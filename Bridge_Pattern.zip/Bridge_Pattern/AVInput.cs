﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bridge_Pattern
{
    public class AVInput : TvInputs
    {
        public override void SwitchInput()
        {
            MessageBox.Show("TV input changed to AV Input", "TV Status Change");
        }
    }
}
