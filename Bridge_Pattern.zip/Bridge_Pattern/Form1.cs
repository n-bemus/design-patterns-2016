﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bridge_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Abstraction abstraction;

        private void btnAV_Click(object sender, EventArgs e)
        {
            abstraction = new AbstractionImp(new AVInput());
            abstraction.SwitchInput();
        }

        private void btnHDMI_Click(object sender, EventArgs e)
        {
            abstraction = new AbstractionImp(new HDMIInput());
            abstraction.SwitchInput();
        }
    }
}
