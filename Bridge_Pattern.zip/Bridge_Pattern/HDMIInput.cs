﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bridge_Pattern
{
    class HDMIInput : TvInputs
    {
        public override void SwitchInput()
        {
            MessageBox.Show("TV input changed to HDMI Input", "TV Status Change");
        }
    }
}
