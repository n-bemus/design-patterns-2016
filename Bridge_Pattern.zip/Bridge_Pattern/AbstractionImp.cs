﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge_Pattern
{
    public class AbstractionImp : Abstraction
    {
        public TvInputs tv;

        //property
        public AbstractionImp(TvInputs t)
        {
            tv = t;
        }

        public virtual void SwitchInput()
        {
            tv.SwitchInput();
        }
    }
}
