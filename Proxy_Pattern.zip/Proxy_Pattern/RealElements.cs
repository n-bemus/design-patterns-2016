﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public class RealElements : Elements
    {
        public override bool simulate(string PlayerOne, string PlayerTwo)
        {
            if ((PlayerOne == "Fire Wave" && PlayerTwo == "Shotgun Ice") ||
            (PlayerOne == "Shotgun Ice" && PlayerTwo == "Electric Spark") ||
            (PlayerOne == "Electric Spark" && PlayerTwo == "Rolling Shield") ||
            (PlayerOne == "Rolling Shield" && PlayerTwo == "Homing Torpedo") ||
            (PlayerOne == "Homing Torpedo" && PlayerTwo == "Boomerang Cutter") ||
            (PlayerOne == "Boomerang Cutter" && PlayerTwo == "Chameleon Sting") ||
            (PlayerOne == "Chameleon Sting" && PlayerTwo == "Storm Tornado") ||
            (PlayerOne == "Storm Tornado" && PlayerTwo == "Fire Wave"))
            {
                return true;
            }

            return false;
        }
    }
}
