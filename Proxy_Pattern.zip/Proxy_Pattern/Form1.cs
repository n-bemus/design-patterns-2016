﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class Form1 : Form
    {
        Proxy proxy = new Proxy();

        public Form1()
        {
            InitializeComponent();
            
            //Player One Combo Box Items
            cbxPlayerOneChoice.Items.Insert(0, "Fire Wave");
            cbxPlayerOneChoice.Items.Insert(1, "Shotgun Ice");
            cbxPlayerOneChoice.Items.Insert(2, "Electric Spark");
            cbxPlayerOneChoice.Items.Insert(3, "Rolling Shield");
            cbxPlayerOneChoice.Items.Insert(4, "Homing Torpedo");
            cbxPlayerOneChoice.Items.Insert(5, "Boomerang Cutter");
            cbxPlayerOneChoice.Items.Insert(6, "Chameleon Sting");
            cbxPlayerOneChoice.Items.Insert(7, "Storm Tornado");

            //Player Two Combo Box Items
            cbxPlayerTwoChoice.Items.Insert(0, "Fire Wave");
            cbxPlayerTwoChoice.Items.Insert(1, "Shotgun Ice");
            cbxPlayerTwoChoice.Items.Insert(2, "Electric Spark");
            cbxPlayerTwoChoice.Items.Insert(3, "Rolling Shield");
            cbxPlayerTwoChoice.Items.Insert(4, "Homing Torpedo");
            cbxPlayerTwoChoice.Items.Insert(5, "Boomerang Cutter");
            cbxPlayerTwoChoice.Items.Insert(6, "Chameleon Sting");
            cbxPlayerTwoChoice.Items.Insert(7, "Storm Tornado");
        }

        private void btnSimulator_Click(object sender, EventArgs e)
        {
            if(cbxPlayerOneChoice.Text == "Pick a weapon")
            {
                MessageBox.Show("Player 1 needs to make a selection");
            }
            else if(cbxPlayerTwoChoice.Text == "Pick a weapon")
            {
                MessageBox.Show("Player 2 needs to make a selection");
            }
            else if(cbxPlayerOneChoice.SelectedIndex == cbxPlayerTwoChoice.SelectedIndex)
            {
                tbxResult.Text = "The battle is draw";
            }
            else
            {
                if(proxy.simulate(cbxPlayerOneChoice.Text, cbxPlayerTwoChoice.Text))
                {
                    tbxResult.Text = "Player 1 is Victorious!";
                }
                else
                {
                    tbxResult.Text = "Player 2 is Victorious!";
                }
            }
        }
    }
}
