﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public class Proxy : Elements
    {
        RealElements _realElements = new RealElements();

        public override bool simulate(string PlayerOne, string PlayerTwo)
        {
           return _realElements.simulate(PlayerOne, PlayerTwo);
        }
    }
}
