﻿namespace Proxy_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxPlayerOneChoice = new System.Windows.Forms.ComboBox();
            this.cbxPlayerTwoChoice = new System.Windows.Forms.ComboBox();
            this.lblPlayerOne = new System.Windows.Forms.Label();
            this.lblPlayerTwo = new System.Windows.Forms.Label();
            this.btnSimulator = new System.Windows.Forms.Button();
            this.tbxResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cbxPlayerOneChoice
            // 
            this.cbxPlayerOneChoice.FormattingEnabled = true;
            this.cbxPlayerOneChoice.Location = new System.Drawing.Point(37, 54);
            this.cbxPlayerOneChoice.Name = "cbxPlayerOneChoice";
            this.cbxPlayerOneChoice.Size = new System.Drawing.Size(121, 24);
            this.cbxPlayerOneChoice.TabIndex = 0;
            this.cbxPlayerOneChoice.Text = "Pick a weapon";
            // 
            // cbxPlayerTwoChoice
            // 
            this.cbxPlayerTwoChoice.FormattingEnabled = true;
            this.cbxPlayerTwoChoice.Location = new System.Drawing.Point(267, 54);
            this.cbxPlayerTwoChoice.Name = "cbxPlayerTwoChoice";
            this.cbxPlayerTwoChoice.Size = new System.Drawing.Size(121, 24);
            this.cbxPlayerTwoChoice.TabIndex = 1;
            this.cbxPlayerTwoChoice.Text = "Pick a weapon";
            // 
            // lblPlayerOne
            // 
            this.lblPlayerOne.AutoSize = true;
            this.lblPlayerOne.Location = new System.Drawing.Point(34, 22);
            this.lblPlayerOne.Name = "lblPlayerOne";
            this.lblPlayerOne.Size = new System.Drawing.Size(60, 17);
            this.lblPlayerOne.TabIndex = 2;
            this.lblPlayerOne.Text = "Player 1";
            // 
            // lblPlayerTwo
            // 
            this.lblPlayerTwo.AutoSize = true;
            this.lblPlayerTwo.Location = new System.Drawing.Point(328, 22);
            this.lblPlayerTwo.Name = "lblPlayerTwo";
            this.lblPlayerTwo.Size = new System.Drawing.Size(60, 17);
            this.lblPlayerTwo.TabIndex = 3;
            this.lblPlayerTwo.Text = "Player 2";
            // 
            // btnSimulator
            // 
            this.btnSimulator.Location = new System.Drawing.Point(37, 101);
            this.btnSimulator.Name = "btnSimulator";
            this.btnSimulator.Size = new System.Drawing.Size(351, 63);
            this.btnSimulator.TabIndex = 4;
            this.btnSimulator.Text = "Simulate";
            this.btnSimulator.UseVisualStyleBackColor = true;
            this.btnSimulator.Click += new System.EventHandler(this.btnSimulator_Click);
            // 
            // tbxResult
            // 
            this.tbxResult.Location = new System.Drawing.Point(37, 189);
            this.tbxResult.Multiline = true;
            this.tbxResult.Name = "tbxResult";
            this.tbxResult.ReadOnly = true;
            this.tbxResult.Size = new System.Drawing.Size(351, 63);
            this.tbxResult.TabIndex = 5;
            this.tbxResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 277);
            this.Controls.Add(this.tbxResult);
            this.Controls.Add(this.btnSimulator);
            this.Controls.Add(this.lblPlayerTwo);
            this.Controls.Add(this.lblPlayerOne);
            this.Controls.Add(this.cbxPlayerTwoChoice);
            this.Controls.Add(this.cbxPlayerOneChoice);
            this.Name = "Form1";
            this.Text = "Megaman X Simulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxPlayerOneChoice;
        private System.Windows.Forms.ComboBox cbxPlayerTwoChoice;
        private System.Windows.Forms.Label lblPlayerOne;
        private System.Windows.Forms.Label lblPlayerTwo;
        private System.Windows.Forms.Button btnSimulator;
        private System.Windows.Forms.TextBox tbxResult;
    }
}

