﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_Pattern
{
    public class Context
    {
        public State _state;

        public bool checkEndGame(bool isTop, int count, int home, int away)
        {
            if (isTop)
            {
                _state = new TopOfInning();
                return _state.IsEndGame(count, home, away);
            }

            _state = new BottomOfInning();
            return _state.IsEndGame(count, home, away);
        }

        public bool changeButton(bool isTop, bool button)
        {
            if (isTop)
            {
                _state = new TopOfInning();
                return _state.IsTeamButton(button);
            }

            _state = new BottomOfInning();
            return _state.IsTeamButton(button);
        }

        public int increaseInningCount(bool isTop, int count)
        {
            if (isTop)
            {
                _state = new TopOfInning();
                return _state.InningCount(count);
            }

            _state = new BottomOfInning();
            return _state.InningCount(count);
        }
    }
}
