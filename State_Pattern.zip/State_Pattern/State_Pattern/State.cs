﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_Pattern
{
    public abstract class State
    {
        //abstract method used for increasing inning count
        public abstract int InningCount(int count);
        //abstract method used for switching if a button is enabled or disabled
        public abstract bool IsTeamButton(bool button);
        //abstract method used for checking for a victor
        public abstract bool IsEndGame(int count, int home, int away);
    }
}
