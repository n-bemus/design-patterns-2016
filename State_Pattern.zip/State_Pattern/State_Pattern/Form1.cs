﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace State_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Context context = new Context();
        bool isTop = true;
        bool isDone = false;

        int home = 0;
        int away = 0;
        int balls = 0;
        int strikes = 0;
        int outs = 0;
        int inning = 1;
        
        bool homebutton = false;
        bool awaybutton = true;

        private void btnHomePoints_Click(object sender, EventArgs e)
        {
            //sets the value of score equal to the value in the textbox
            home = Convert.ToInt32(tbxHomeScore.Text);
            home++;

            //converts back into a string for display purposes
            tbxHomeScore.Text = Convert.ToString(home);

            //checks for a end of game result
            if (inning >= 9)
            {
                //calls the checkEndGame function from context class sending in this format (bool, int, int, int)
                isDone = context.checkEndGame(isTop, inning, home, away);

                if (isDone && !isTop)
                {
                    //disable all buttons
                    btnAddBall.Enabled = false;
                    btnAddOut.Enabled = false;
                    btnAddStrike.Enabled = false;
                    btnAwayPoints.Enabled = false;
                    btnHomePoints.Enabled = false;

                    if (home > away)
                    {
                        lblWinner.Text = "Home Team is Victor!";
                    }

                }
            }
        }

        private void btnAwayPoints_Click(object sender, EventArgs e)
        {
            away = Convert.ToInt32(tbxAwayScore.Text);
            away++;
            tbxAwayScore.Text = Convert.ToString(away);

            if (inning >= 9 && isTop)
            {
                isDone = context.checkEndGame(isTop, inning, home, away);

                if (isDone)
                {
                    //disable all buttons
                    btnAddBall.Enabled = false;
                    btnAddOut.Enabled = false;
                    btnAddStrike.Enabled = false;
                    btnAwayPoints.Enabled = false;
                    btnHomePoints.Enabled = false;

                    if (home > away)
                    {
                        lblWinner.Text = "Home Team is Victor!";
                    }
                }
            }
        }

        private void btnAddBall_Click(object sender, EventArgs e)
        {
            balls = Convert.ToInt32(tbxBallCount.Text);
            balls++;

            //checks for a walk on base
            if (balls == 4)
            {
                tbxBallCount.Text = "0";
                tbxStrikeCount.Text = "0";
            }

            else
            {
                tbxBallCount.Text = Convert.ToString(balls);
            }
        }

        private void btnAddStrike_Click(object sender, EventArgs e)
        {
            strikes = Convert.ToInt32(tbxStrikeCount.Text);
            strikes++;

            //if there are 3 strikes
            if (strikes == 3)
            {
                tbxBallCount.Text = "0";
                tbxStrikeCount.Text = "0";

                //adds an out to the out counter
                outs = Convert.ToInt32(tbxOutCount.Text);
                outs++;
                tbxOutCount.Text = Convert.ToString(outs);

                //checks the outs for a state change
                if (outs == 3)
                {
                    //checks for a victory
                    if (inning >= 9)
                    {
                        isDone = context.checkEndGame(isTop, inning, home, away);

                        //runs the check win based off of the state of the inning

                        //top of the inning
                        if (isDone && isTop)
                        {
                            //if home team has more points
                            if (home > away)
                            {
                                lblWinner.Text = "Home Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }
                        }

                        //bottom of the inning
                        if (isDone && !isTop)
                        {
                            if (home > away)
                            {
                                lblWinner.Text = "Home Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }

                            else if (away > home)
                            {
                                lblWinner.Text = "Away Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }

                            else
                            {
                                inning = context.increaseInningCount(isTop, inning);

                                //changes isTop to either true or false
                                if (isTop)
                                {
                                    isTop = false;
                                }
                                else
                                {
                                    isTop = true;
                                }

                                //switches the functionality for the buttons
                                awaybutton = context.changeButton(isTop, awaybutton);
                                homebutton = context.changeButton(isTop, homebutton);

                                btnAwayPoints.Enabled = awaybutton;
                                btnHomePoints.Enabled = homebutton;
                                lblTop.Visible = awaybutton;
                                lblBottom.Visible = homebutton;

                                tbxOutCount.Text = "0";
                                tbxBallCount.Text = "0";
                                tbxStrikeCount.Text = "0";

                                lblInning.Text = "Inning: " + inning;
                            }
                        }
                    }

                    //Change innings
                    else
                    {
                        inning = context.increaseInningCount(isTop, inning);

                        //changes isTop to either true or false
                        if (isTop)
                        {
                            isTop = false;
                        }
                        else
                        {
                            isTop = true;
                        }

                        //switches the functionality for the buttons
                        awaybutton = context.changeButton(isTop, awaybutton);
                        homebutton = context.changeButton(isTop, homebutton);

                        btnAwayPoints.Enabled = awaybutton;
                        btnHomePoints.Enabled = homebutton;
                        lblTop.Visible = awaybutton;
                        lblBottom.Visible = homebutton;

                        tbxOutCount.Text = "0";
                        tbxBallCount.Text = "0";
                        tbxStrikeCount.Text = "0";

                        lblInning.Text = "Inning: " + inning;
                    }
                }
            }

            //prints out the new strike count
            else
            {
                tbxStrikeCount.Text = Convert.ToString(strikes);
            }
        }

        private void btnAddOut_Click(object sender, EventArgs e)
        {
            outs = Convert.ToInt32(tbxOutCount.Text);
            outs++;

            if (outs == 3)
            {
                tbxBallCount.Text = "0";
                tbxStrikeCount.Text = "0";

                //adds an out to the out counter
                outs = Convert.ToInt32(tbxOutCount.Text);
                outs++;
                tbxOutCount.Text = Convert.ToString(outs);

                //checks the outs for a state change
                if (outs == 3)
                {
                    //checks for a victory
                    if (inning >= 9)
                    {
                        isDone = context.checkEndGame(isTop, inning, home, away);

                        //runs the check win based off of the state of the inning

                        //top of the inning
                        if (isDone && isTop)
                        {
                            //if home team has more points
                            if (home > away)
                            {
                                lblWinner.Text = "Home Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }
                        }

                        //bottom of the inning
                        if (isDone && !isTop)
                        {
                            if (home > away)
                            {
                                lblWinner.Text = "Home Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }

                            else if (away > home)
                            {
                                lblWinner.Text = "Away Team is Victor!";

                                //disable all buttons
                                btnAddBall.Enabled = false;
                                btnAddOut.Enabled = false;
                                btnAddStrike.Enabled = false;
                                btnAwayPoints.Enabled = false;
                                btnHomePoints.Enabled = false;
                            }

                            
                        }
                        else
                        {
                            inning = context.increaseInningCount(isTop, inning);

                            //changes isTop to either true or false
                            if (isTop)
                            {
                                isTop = false;
                            }
                            else
                            {
                                isTop = true;
                            }

                            //switches the functionality for the buttons
                            awaybutton = context.changeButton(isTop, awaybutton);
                            homebutton = context.changeButton(isTop, homebutton);

                            btnAwayPoints.Enabled = awaybutton;
                            btnHomePoints.Enabled = homebutton;
                            lblTop.Visible = awaybutton;
                            lblBottom.Visible = homebutton;

                            tbxOutCount.Text = "0";
                            tbxBallCount.Text = "0";
                            tbxStrikeCount.Text = "0";

                            lblInning.Text = "Inning: " + inning;
                        }
                    }

                    //Change innings
                    else
                    {
                        inning = context.increaseInningCount(isTop, inning);

                        //changes isTop to either true or false
                        if (isTop)
                        {
                            isTop = false;
                        }
                        else
                        {
                            isTop = true;
                        }

                        //switches the functionality for the buttons
                        awaybutton = context.changeButton(isTop, awaybutton);
                        homebutton = context.changeButton(isTop, homebutton);

                        btnAwayPoints.Enabled = awaybutton;
                        btnHomePoints.Enabled = homebutton;
                        lblTop.Visible = awaybutton;
                        lblBottom.Visible = homebutton;

                        tbxOutCount.Text = "0";
                        tbxBallCount.Text = "0";
                        tbxStrikeCount.Text = "0";

                        lblInning.Text = "Inning: " + inning;
                    }
                }
            }

            //prints out the new out count
            else
            {
                tbxOutCount.Text = Convert.ToString(outs);
            }
        }
    }
}
