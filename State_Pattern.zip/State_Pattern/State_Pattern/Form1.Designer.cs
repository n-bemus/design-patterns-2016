﻿namespace State_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHomePoints = new System.Windows.Forms.Button();
            this.btnAwayPoints = new System.Windows.Forms.Button();
            this.tbxHomeScore = new System.Windows.Forms.TextBox();
            this.tbxAwayScore = new System.Windows.Forms.TextBox();
            this.lblTop = new System.Windows.Forms.Label();
            this.lblInning = new System.Windows.Forms.Label();
            this.lblBottom = new System.Windows.Forms.Label();
            this.lblHome = new System.Windows.Forms.Label();
            this.lblAway = new System.Windows.Forms.Label();
            this.btnAddBall = new System.Windows.Forms.Button();
            this.btnAddStrike = new System.Windows.Forms.Button();
            this.btnAddOut = new System.Windows.Forms.Button();
            this.tbxBallCount = new System.Windows.Forms.TextBox();
            this.tbxStrikeCount = new System.Windows.Forms.TextBox();
            this.tbxOutCount = new System.Windows.Forms.TextBox();
            this.lblWinner = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnHomePoints
            // 
            this.btnHomePoints.Enabled = false;
            this.btnHomePoints.Location = new System.Drawing.Point(40, 119);
            this.btnHomePoints.Name = "btnHomePoints";
            this.btnHomePoints.Size = new System.Drawing.Size(85, 47);
            this.btnHomePoints.TabIndex = 0;
            this.btnHomePoints.Text = "Add Points\r\n to Home";
            this.btnHomePoints.UseVisualStyleBackColor = true;
            this.btnHomePoints.Click += new System.EventHandler(this.btnHomePoints_Click);
            // 
            // btnAwayPoints
            // 
            this.btnAwayPoints.Location = new System.Drawing.Point(357, 119);
            this.btnAwayPoints.Name = "btnAwayPoints";
            this.btnAwayPoints.Size = new System.Drawing.Size(85, 47);
            this.btnAwayPoints.TabIndex = 1;
            this.btnAwayPoints.Text = "Add Points\r\n to Away";
            this.btnAwayPoints.UseVisualStyleBackColor = true;
            this.btnAwayPoints.Click += new System.EventHandler(this.btnAwayPoints_Click);
            // 
            // tbxHomeScore
            // 
            this.tbxHomeScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxHomeScore.Location = new System.Drawing.Point(40, 49);
            this.tbxHomeScore.Multiline = true;
            this.tbxHomeScore.Name = "tbxHomeScore";
            this.tbxHomeScore.Size = new System.Drawing.Size(85, 57);
            this.tbxHomeScore.TabIndex = 2;
            this.tbxHomeScore.Text = "0";
            this.tbxHomeScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbxAwayScore
            // 
            this.tbxAwayScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxAwayScore.Location = new System.Drawing.Point(357, 46);
            this.tbxAwayScore.Multiline = true;
            this.tbxAwayScore.Name = "tbxAwayScore";
            this.tbxAwayScore.Size = new System.Drawing.Size(85, 57);
            this.tbxAwayScore.TabIndex = 3;
            this.tbxAwayScore.Text = "0";
            this.tbxAwayScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTop
            // 
            this.lblTop.AutoSize = true;
            this.lblTop.Location = new System.Drawing.Point(225, 89);
            this.lblTop.Name = "lblTop";
            this.lblTop.Size = new System.Drawing.Size(33, 17);
            this.lblTop.TabIndex = 4;
            this.lblTop.Text = "Top";
            // 
            // lblInning
            // 
            this.lblInning.AutoSize = true;
            this.lblInning.Location = new System.Drawing.Point(210, 119);
            this.lblInning.Name = "lblInning";
            this.lblInning.Size = new System.Drawing.Size(62, 17);
            this.lblInning.TabIndex = 5;
            this.lblInning.Text = "Inning: 1";
            // 
            // lblBottom
            // 
            this.lblBottom.AutoSize = true;
            this.lblBottom.Location = new System.Drawing.Point(215, 149);
            this.lblBottom.Name = "lblBottom";
            this.lblBottom.Size = new System.Drawing.Size(52, 17);
            this.lblBottom.TabIndex = 6;
            this.lblBottom.Text = "Bottom";
            this.lblBottom.Visible = false;
            // 
            // lblHome
            // 
            this.lblHome.AutoSize = true;
            this.lblHome.Location = new System.Drawing.Point(40, 26);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(45, 17);
            this.lblHome.TabIndex = 10;
            this.lblHome.Text = "Home";
            // 
            // lblAway
            // 
            this.lblAway.AutoSize = true;
            this.lblAway.Location = new System.Drawing.Point(401, 26);
            this.lblAway.Name = "lblAway";
            this.lblAway.Size = new System.Drawing.Size(41, 17);
            this.lblAway.TabIndex = 11;
            this.lblAway.Text = "Away";
            // 
            // btnAddBall
            // 
            this.btnAddBall.Location = new System.Drawing.Point(66, 249);
            this.btnAddBall.Name = "btnAddBall";
            this.btnAddBall.Size = new System.Drawing.Size(59, 49);
            this.btnAddBall.TabIndex = 12;
            this.btnAddBall.Text = "Add Ball";
            this.btnAddBall.UseVisualStyleBackColor = true;
            this.btnAddBall.Click += new System.EventHandler(this.btnAddBall_Click);
            // 
            // btnAddStrike
            // 
            this.btnAddStrike.Location = new System.Drawing.Point(213, 249);
            this.btnAddStrike.Name = "btnAddStrike";
            this.btnAddStrike.Size = new System.Drawing.Size(59, 49);
            this.btnAddStrike.TabIndex = 13;
            this.btnAddStrike.Text = "Add Strike";
            this.btnAddStrike.UseVisualStyleBackColor = true;
            this.btnAddStrike.Click += new System.EventHandler(this.btnAddStrike_Click);
            // 
            // btnAddOut
            // 
            this.btnAddOut.Location = new System.Drawing.Point(357, 249);
            this.btnAddOut.Name = "btnAddOut";
            this.btnAddOut.Size = new System.Drawing.Size(59, 49);
            this.btnAddOut.TabIndex = 14;
            this.btnAddOut.Text = "Add Out";
            this.btnAddOut.UseVisualStyleBackColor = true;
            this.btnAddOut.Click += new System.EventHandler(this.btnAddOut_Click);
            // 
            // tbxBallCount
            // 
            this.tbxBallCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxBallCount.Location = new System.Drawing.Point(66, 189);
            this.tbxBallCount.Multiline = true;
            this.tbxBallCount.Name = "tbxBallCount";
            this.tbxBallCount.Size = new System.Drawing.Size(59, 43);
            this.tbxBallCount.TabIndex = 15;
            this.tbxBallCount.Text = "0";
            this.tbxBallCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbxStrikeCount
            // 
            this.tbxStrikeCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxStrikeCount.Location = new System.Drawing.Point(213, 189);
            this.tbxStrikeCount.Multiline = true;
            this.tbxStrikeCount.Name = "tbxStrikeCount";
            this.tbxStrikeCount.Size = new System.Drawing.Size(59, 43);
            this.tbxStrikeCount.TabIndex = 15;
            this.tbxStrikeCount.Text = "0";
            this.tbxStrikeCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbxOutCount
            // 
            this.tbxOutCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxOutCount.Location = new System.Drawing.Point(357, 189);
            this.tbxOutCount.Multiline = true;
            this.tbxOutCount.Name = "tbxOutCount";
            this.tbxOutCount.Size = new System.Drawing.Size(59, 43);
            this.tbxOutCount.TabIndex = 15;
            this.tbxOutCount.Text = "0";
            this.tbxOutCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWinner
            // 
            this.lblWinner.AutoSize = true;
            this.lblWinner.Location = new System.Drawing.Point(171, 339);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(141, 17);
            this.lblWinner.TabIndex = 16;
            this.lblWinner.Text = "There is no victor yet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 381);
            this.Controls.Add(this.lblWinner);
            this.Controls.Add(this.tbxOutCount);
            this.Controls.Add(this.tbxStrikeCount);
            this.Controls.Add(this.tbxBallCount);
            this.Controls.Add(this.btnAddOut);
            this.Controls.Add(this.btnAddStrike);
            this.Controls.Add(this.btnAddBall);
            this.Controls.Add(this.lblAway);
            this.Controls.Add(this.lblHome);
            this.Controls.Add(this.lblBottom);
            this.Controls.Add(this.lblInning);
            this.Controls.Add(this.lblTop);
            this.Controls.Add(this.tbxAwayScore);
            this.Controls.Add(this.tbxHomeScore);
            this.Controls.Add(this.btnAwayPoints);
            this.Controls.Add(this.btnHomePoints);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHomePoints;
        private System.Windows.Forms.Button btnAwayPoints;
        private System.Windows.Forms.TextBox tbxHomeScore;
        private System.Windows.Forms.TextBox tbxAwayScore;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.Label lblInning;
        private System.Windows.Forms.Label lblBottom;
        private System.Windows.Forms.Label lblHome;
        private System.Windows.Forms.Label lblAway;
        private System.Windows.Forms.Button btnAddBall;
        private System.Windows.Forms.Button btnAddStrike;
        private System.Windows.Forms.Button btnAddOut;
        private System.Windows.Forms.TextBox tbxBallCount;
        private System.Windows.Forms.TextBox tbxStrikeCount;
        private System.Windows.Forms.TextBox tbxOutCount;
        private System.Windows.Forms.Label lblWinner;
    }
}

