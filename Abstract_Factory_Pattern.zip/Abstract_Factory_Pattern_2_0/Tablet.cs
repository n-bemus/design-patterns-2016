﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract_Factory_Pattern_2_0
{
    public class PCTablet
    {
        public PCTablet() { }

        public PCTablet(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
               '\n' + "Operating System: " + OS, "Product Created");
        }
    }

    public class MacTablet
    {
        public MacTablet() { }

        public MacTablet(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
                   '\n' + "Operating System: " + OS, "Product Created");
        }
    }
}
