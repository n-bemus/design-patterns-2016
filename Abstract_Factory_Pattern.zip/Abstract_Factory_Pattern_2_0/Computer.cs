﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract_Factory_Pattern_2_0
{
    public class PCComputer
    {
        public PCComputer() { }

        public PCComputer(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
               '\n' + "Operating System: " + OS, "Product Created");
        }
    }

    public class MacComputer
    {
        public MacComputer() { }

        public MacComputer(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
                   '\n' + "Operating System: " + OS, "Product Created");
        }
    }
}
