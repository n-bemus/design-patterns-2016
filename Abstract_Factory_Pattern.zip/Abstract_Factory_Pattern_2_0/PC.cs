﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory_Pattern_2_0
{
    //concrete factory
    public class PC : AbstractFactory
    {
        public override PCComputer createPCComputer(string Company, string elecType, string OS)
        {
            return new PCComputer(Company, elecType, OS);
        }

        public override PCTablet createPCTablet(string Company, string elecType, string OS)
        {
            return new PCTablet(Company, elecType, OS);
        }

        public override PCPhone createPCPhone(string Company, string elecType, string OS)
        {
            return new PCPhone(Company, elecType, OS);
        }

        public override MacComputer createMacComputer(string Company, string elecType, string OS) { throw new NotImplementedException(); }
        public override MacTablet createMacTablet(string Company, string elecType, string OS) { throw new NotImplementedException(); }
        public override MacPhone createMacPhone(string Company, string elecType, string OS) { throw new NotImplementedException(); }
    }
}
