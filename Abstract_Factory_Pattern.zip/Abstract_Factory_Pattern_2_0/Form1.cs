﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract_Factory_Pattern_2_0
{
    public partial class Form1 : Form
    {
        PC factory1;
        Mac factory2;
        PCComputer pcc;
        PCTablet pct;
        PCPhone pcp;
        MacComputer mc;
        MacTablet mt;
        MacPhone mp;

        string company;
        string elecType;
        string OS;

        public Form1()
        {
            InitializeComponent();
            factory1 = new PC();
            factory2 = new Mac();
            pcc = new PCComputer();
            pct = new PCTablet();
            pcp = new PCPhone();
            mc = new MacComputer();
            mt = new MacTablet();
            mp = new MacPhone();
        }

        private void btnPCComputer_Click(object sender, EventArgs e)
        {
            company = "Microsoft";
            elecType = "Computer";
            OS = "Windows 10";
            factory1.createPCComputer(company, elecType, OS);
        }

        private void btnPCTablet_Click(object sender, EventArgs e)
        {
            company = "Microsoft";
            elecType = "Tablet";
            OS = "Windows 10";
            factory1.createPCTablet(company, elecType, OS);
        }

        private void btnPCPhone_Click(object sender, EventArgs e)
        {
            company = "Microsoft";
            elecType = "Phone";
            OS = "Windows 10 Mobile";
            factory1.createPCPhone(company, elecType, OS);
        }

        private void btnMacComputer_Click(object sender, EventArgs e)
        {
            company = "Apple";
            elecType = "Computer";
            OS = "OSX";
            factory2.createMacComputer(company, elecType, OS);
        }

        private void btnMacTablet_Click(object sender, EventArgs e)
        {
            company = "Apple";
            elecType = "Tablet";
            OS = "iOS 10";
            factory2.createMacTablet(company, elecType, OS);
        }

        private void btnMacPhone_Click(object sender, EventArgs e)
        {
            company = "Apple";
            elecType = "Phone";
            OS = "iOS 10";
            factory2.createMacPhone(company, elecType, OS);
        }
    }
}
