﻿namespace Abstract_Factory_Pattern_2_0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPCComputer = new System.Windows.Forms.Button();
            this.btnPCPhone = new System.Windows.Forms.Button();
            this.btnMacComputer = new System.Windows.Forms.Button();
            this.btnMacTablet = new System.Windows.Forms.Button();
            this.btnMacPhone = new System.Windows.Forms.Button();
            this.btnPCTablet = new System.Windows.Forms.Button();
            this.lblPCTitle = new System.Windows.Forms.Label();
            this.lblMacOptions = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPCComputer
            // 
            this.btnPCComputer.Location = new System.Drawing.Point(52, 85);
            this.btnPCComputer.Name = "btnPCComputer";
            this.btnPCComputer.Size = new System.Drawing.Size(91, 36);
            this.btnPCComputer.TabIndex = 0;
            this.btnPCComputer.Text = "Computer";
            this.btnPCComputer.UseVisualStyleBackColor = true;
            this.btnPCComputer.Click += new System.EventHandler(this.btnPCComputer_Click);
            // 
            // btnPCPhone
            // 
            this.btnPCPhone.Location = new System.Drawing.Point(298, 85);
            this.btnPCPhone.Name = "btnPCPhone";
            this.btnPCPhone.Size = new System.Drawing.Size(91, 36);
            this.btnPCPhone.TabIndex = 1;
            this.btnPCPhone.Text = "Phone";
            this.btnPCPhone.UseVisualStyleBackColor = true;
            this.btnPCPhone.Click += new System.EventHandler(this.btnPCPhone_Click);
            // 
            // btnMacComputer
            // 
            this.btnMacComputer.Location = new System.Drawing.Point(52, 207);
            this.btnMacComputer.Name = "btnMacComputer";
            this.btnMacComputer.Size = new System.Drawing.Size(91, 36);
            this.btnMacComputer.TabIndex = 2;
            this.btnMacComputer.Text = "Computer";
            this.btnMacComputer.UseVisualStyleBackColor = true;
            this.btnMacComputer.Click += new System.EventHandler(this.btnMacComputer_Click);
            // 
            // btnMacTablet
            // 
            this.btnMacTablet.Location = new System.Drawing.Point(176, 207);
            this.btnMacTablet.Name = "btnMacTablet";
            this.btnMacTablet.Size = new System.Drawing.Size(91, 36);
            this.btnMacTablet.TabIndex = 3;
            this.btnMacTablet.Text = "Tablet";
            this.btnMacTablet.UseVisualStyleBackColor = true;
            this.btnMacTablet.Click += new System.EventHandler(this.btnMacTablet_Click);
            // 
            // btnMacPhone
            // 
            this.btnMacPhone.Location = new System.Drawing.Point(298, 207);
            this.btnMacPhone.Name = "btnMacPhone";
            this.btnMacPhone.Size = new System.Drawing.Size(91, 36);
            this.btnMacPhone.TabIndex = 4;
            this.btnMacPhone.Text = "Phone";
            this.btnMacPhone.UseVisualStyleBackColor = true;
            this.btnMacPhone.Click += new System.EventHandler(this.btnMacPhone_Click);
            // 
            // btnPCTablet
            // 
            this.btnPCTablet.Location = new System.Drawing.Point(176, 85);
            this.btnPCTablet.Name = "btnPCTablet";
            this.btnPCTablet.Size = new System.Drawing.Size(91, 36);
            this.btnPCTablet.TabIndex = 5;
            this.btnPCTablet.Text = "Tablet";
            this.btnPCTablet.UseVisualStyleBackColor = true;
            this.btnPCTablet.Click += new System.EventHandler(this.btnPCTablet_Click);
            // 
            // lblPCTitle
            // 
            this.lblPCTitle.AutoSize = true;
            this.lblPCTitle.Location = new System.Drawing.Point(173, 36);
            this.lblPCTitle.Name = "lblPCTitle";
            this.lblPCTitle.Size = new System.Drawing.Size(79, 17);
            this.lblPCTitle.TabIndex = 6;
            this.lblPCTitle.Text = "PC Options";
            // 
            // lblMacOptions
            // 
            this.lblMacOptions.AutoSize = true;
            this.lblMacOptions.Location = new System.Drawing.Point(169, 152);
            this.lblMacOptions.Name = "lblMacOptions";
            this.lblMacOptions.Size = new System.Drawing.Size(87, 17);
            this.lblMacOptions.TabIndex = 7;
            this.lblMacOptions.Text = "Mac Options";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 295);
            this.Controls.Add(this.lblMacOptions);
            this.Controls.Add(this.lblPCTitle);
            this.Controls.Add(this.btnPCTablet);
            this.Controls.Add(this.btnMacPhone);
            this.Controls.Add(this.btnMacTablet);
            this.Controls.Add(this.btnMacComputer);
            this.Controls.Add(this.btnPCPhone);
            this.Controls.Add(this.btnPCComputer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPCComputer;
        private System.Windows.Forms.Button btnPCPhone;
        private System.Windows.Forms.Button btnMacComputer;
        private System.Windows.Forms.Button btnMacTablet;
        private System.Windows.Forms.Button btnMacPhone;
        private System.Windows.Forms.Button btnPCTablet;
        private System.Windows.Forms.Label lblPCTitle;
        private System.Windows.Forms.Label lblMacOptions;
    }
}

