﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory_Pattern_2_0
{
    public abstract class AbstractFactory
    {
        public abstract PCComputer createPCComputer(string Company, string elecType, string OS);
        public abstract PCTablet createPCTablet(string Company, string elecType, string OS);
        public abstract PCPhone createPCPhone(string Company, string elecType, string OS);

        public abstract MacComputer createMacComputer(string Company, string elecType, string OS);
        public abstract MacTablet createMacTablet(string Company, string elecType, string OS);
        public abstract MacPhone createMacPhone(string Company, string elecType, string OS);
    }
}
