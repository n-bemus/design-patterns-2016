﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract_Factory_Pattern_2_0
{
    public class PCPhone
    {
        public PCPhone() { }

        public PCPhone(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
               '\n' + "Operating System: " + OS, "Product Created");
        }
    }

    public class MacPhone
    {
        public MacPhone() { }

        public MacPhone(string Company, string elecType, string OS)
        {
            MessageBox.Show("Company Brand: " + Company + '\n' + "Electronic Type: " + elecType +
                   '\n' + "Operating System: " + OS, "Product Created");
        }
    }
}
