﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_Pattern
{
    public class TopOfInning : State
    {
        int _count;

        //returns the number unchanged
        public override int InningCount(int count)
        {
            _count = count;
            return _count;
        }

        //changes true to false or visa versa
        public override bool IsTeamButton(bool button)
        {
            if (button != true)
            {
                return true;
            }
            return false;
        }

        //This is the end game checker that may have some issues but I have no clue where they are at
        public override bool IsEndGame(int count, int home, int away)
        {
            if (count >= 9)
            {
                if (home != away)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
