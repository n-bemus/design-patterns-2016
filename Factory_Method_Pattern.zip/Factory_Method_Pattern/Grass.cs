﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factory_Method_Pattern
{
    class Grass : Pokemon
    {
        private string name;
        private string pokemonType = "Grass";
        private string ability = "Overgrow";

        public Grass(string name)
        {
            this.name = name;
        }


        public void createPokemon()
        {
            MessageBox.Show("Pokémon Name: " + name + '\n' + "Pokémon Type: " + pokemonType +
               '\n' + "Pokémon Ability: " + ability, "Pokémon Created");
        }

        public string getPokemonAbility()
        {
            return ability;
        }

        public string getPokemonType()
        {
            return pokemonType;
        }

        public string getPokemonName()
        {
            return name;
        }
    }
}
