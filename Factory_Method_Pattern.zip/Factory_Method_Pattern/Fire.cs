﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factory_Method_Pattern
{
    class Fire : Pokemon
    {
        private string name;
        private string pokemonType = "Fire";
        private string ability = "Flash Fire";

        public Fire(string name)
        {
            this.name = name;
        }

        public void createPokemon()
        {
            MessageBox.Show("Pokémon Name: " + name + '\n' + "Pokémon Type: " + pokemonType +
               '\n' + "Pokémon Ability: " + ability, "Pokémon Created");
        }


        public string getPokemonType()
        {
            return pokemonType;
        }

        public string getPokemonName()
        {
            return name;
        }

        public string getPokemonAbility()
        {
            return ability;
        }

    }
}
