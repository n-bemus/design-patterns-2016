﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    public abstract class Factory
    {
        public void createPokemon(string type, string name, string ability)
        {
            Pokemon pokemon = createNewPokemon(type, name, ability);
            pokemon.createPokemon();

        }

        public abstract Pokemon createNewPokemon(string type, string name, string ability);
    }
}
