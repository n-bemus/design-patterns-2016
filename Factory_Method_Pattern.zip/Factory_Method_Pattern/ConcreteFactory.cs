﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    class ConcreteFactory : Factory
    {
        public override Pokemon createNewPokemon(string type, string name, string ability)
        {

            if (type == "Fire")
            {
                return new Fire(name);
            }
            else if (type == "Water")
            {
                return new Water(name);
            }
            else if (type == "Grass")
            {
                return new Grass(name);
            }

            return null;
        }
    }
}
