﻿namespace Factory_Method_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxPokemonName = new System.Windows.Forms.TextBox();
            this.lblPokemonNamePrompt = new System.Windows.Forms.Label();
            this.lblPokemonTypePrompt = new System.Windows.Forms.Label();
            this.rbnFireType = new System.Windows.Forms.RadioButton();
            this.rbnWaterType = new System.Windows.Forms.RadioButton();
            this.rbnGrassType = new System.Windows.Forms.RadioButton();
            this.btnCreatePokemon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbxPokemonName
            // 
            this.tbxPokemonName.Location = new System.Drawing.Point(273, 36);
            this.tbxPokemonName.Name = "tbxPokemonName";
            this.tbxPokemonName.Size = new System.Drawing.Size(193, 22);
            this.tbxPokemonName.TabIndex = 0;
            // 
            // lblPokemonNamePrompt
            // 
            this.lblPokemonNamePrompt.AutoSize = true;
            this.lblPokemonNamePrompt.Location = new System.Drawing.Point(36, 39);
            this.lblPokemonNamePrompt.Name = "lblPokemonNamePrompt";
            this.lblPokemonNamePrompt.Size = new System.Drawing.Size(173, 17);
            this.lblPokemonNamePrompt.TabIndex = 1;
            this.lblPokemonNamePrompt.Text = "Type in a Pokemon name:";
            // 
            // lblPokemonTypePrompt
            // 
            this.lblPokemonTypePrompt.AutoSize = true;
            this.lblPokemonTypePrompt.Location = new System.Drawing.Point(167, 96);
            this.lblPokemonTypePrompt.Name = "lblPokemonTypePrompt";
            this.lblPokemonTypePrompt.Size = new System.Drawing.Size(158, 17);
            this.lblPokemonTypePrompt.TabIndex = 5;
            this.lblPokemonTypePrompt.Text = "Select a Pokemon Type";
            // 
            // rbnFireType
            // 
            this.rbnFireType.AutoSize = true;
            this.rbnFireType.Location = new System.Drawing.Point(39, 151);
            this.rbnFireType.Name = "rbnFireType";
            this.rbnFireType.Size = new System.Drawing.Size(89, 21);
            this.rbnFireType.TabIndex = 6;
            this.rbnFireType.TabStop = true;
            this.rbnFireType.Text = "Fire Type";
            this.rbnFireType.UseVisualStyleBackColor = true;
            this.rbnFireType.CheckedChanged += new System.EventHandler(this.rbnFireType_CheckedChanged);
            // 
            // rbnWaterType
            // 
            this.rbnWaterType.AutoSize = true;
            this.rbnWaterType.Location = new System.Drawing.Point(197, 151);
            this.rbnWaterType.Name = "rbnWaterType";
            this.rbnWaterType.Size = new System.Drawing.Size(103, 21);
            this.rbnWaterType.TabIndex = 7;
            this.rbnWaterType.TabStop = true;
            this.rbnWaterType.Text = "Water Type";
            this.rbnWaterType.UseVisualStyleBackColor = true;
            this.rbnWaterType.CheckedChanged += new System.EventHandler(this.rbnWaterType_CheckedChanged);
            // 
            // rbnGrassType
            // 
            this.rbnGrassType.AutoSize = true;
            this.rbnGrassType.Location = new System.Drawing.Point(355, 151);
            this.rbnGrassType.Name = "rbnGrassType";
            this.rbnGrassType.Size = new System.Drawing.Size(103, 21);
            this.rbnGrassType.TabIndex = 8;
            this.rbnGrassType.TabStop = true;
            this.rbnGrassType.Text = "Grass Type";
            this.rbnGrassType.UseVisualStyleBackColor = true;
            this.rbnGrassType.CheckedChanged += new System.EventHandler(this.rbnGrassType_CheckedChanged);
            // 
            // btnCreatePokemon
            // 
            this.btnCreatePokemon.Location = new System.Drawing.Point(170, 241);
            this.btnCreatePokemon.Name = "btnCreatePokemon";
            this.btnCreatePokemon.Size = new System.Drawing.Size(155, 23);
            this.btnCreatePokemon.TabIndex = 9;
            this.btnCreatePokemon.Text = "Create Pokemon";
            this.btnCreatePokemon.UseVisualStyleBackColor = true;
            this.btnCreatePokemon.Click += new System.EventHandler(this.btnCreatePokemon_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 319);
            this.Controls.Add(this.btnCreatePokemon);
            this.Controls.Add(this.rbnGrassType);
            this.Controls.Add(this.rbnWaterType);
            this.Controls.Add(this.rbnFireType);
            this.Controls.Add(this.lblPokemonTypePrompt);
            this.Controls.Add(this.lblPokemonNamePrompt);
            this.Controls.Add(this.tbxPokemonName);
            this.Name = "Form1";
            this.Text = "Pokemon Maker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxPokemonName;
        private System.Windows.Forms.Label lblPokemonNamePrompt;
        private System.Windows.Forms.Label lblPokemonTypePrompt;
        private System.Windows.Forms.RadioButton rbnFireType;
        private System.Windows.Forms.RadioButton rbnWaterType;
        private System.Windows.Forms.RadioButton rbnGrassType;
        private System.Windows.Forms.Button btnCreatePokemon;
    }
}

