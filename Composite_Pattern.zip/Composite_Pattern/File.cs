﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite_Pattern
{
    public class File : Memory
    {
        string fileType;
        string display;
        string current;

        private List<Memory> memoryUsed = new List<Memory>();

        public override void add(Memory file)
        {
            memoryUsed.Add(file);
        }

        public override void remove(Memory file)
        {
            memoryUsed.Remove(file);
        }

        public override string Display(int depth)
        {
            foreach (Memory memory in memoryUsed)
            {
                if (fileType == "Gaming")
                {
                    display = "Gaming :" + System.Environment.NewLine;
                }
                display += memory.Display(depth + 2);
            }
            current = display;
            display = "";
            return current;
        }

        public File(string type)
        {
            fileType = type;
        }
    }
}
