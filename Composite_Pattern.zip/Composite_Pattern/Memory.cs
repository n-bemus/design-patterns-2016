﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite_Pattern
{
    public abstract class Memory
    {
        string fileType;
        public abstract string Display(int depth);
        public abstract void remove(Memory file);
        public abstract void add(Memory file);
    }
}
