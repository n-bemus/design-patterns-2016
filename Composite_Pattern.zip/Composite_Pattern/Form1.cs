﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Composite_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int memoryAllocated = 0;
        File file = new File("File");
        File gaming = new File("Gaming");
        File media = new File("Media");

        private void btnCreateFile_Click(object sender, EventArgs e)
        {
            file.add(new Individual("File", 1));
            memoryAllocated += 1;
            tbxMemoryStatus.Text = file.Display(1);
            lblMemoryStatus.Text = "Memory Used- " + memoryAllocated;
        }

        private void btnCreateGame_Click(object sender, EventArgs e)
        {
            gaming.add(new Individual("Gaming", 10000));
            memoryAllocated += 10000;
            
            file.add(gaming);
            tbxMemoryStatus.Text = file.Display(1);
            lblMemoryStatus.Text = "Memory Used- " + memoryAllocated;
        }

        private void btnCreateDoc_Click(object sender, EventArgs e)
        {
            file.add(new Individual("Document", 10));
            memoryAllocated += 10;
            tbxMemoryStatus.Text = file.Display(1);
            lblMemoryStatus.Text = "Memory Used- " + memoryAllocated;
        }

        private void btnCreateMediaFile_Click(object sender, EventArgs e)
        {
            file.add(new Individual("Media", 1000));
            memoryAllocated += 1000;
            tbxMemoryStatus.Text = file.Display(1);
            lblMemoryStatus.Text = "Memory Used- " + memoryAllocated;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            memoryAllocated = 0;
            tbxMemoryStatus.Text = "";
            lblMemoryStatus.Text = "Memory Used- " + memoryAllocated;
        }
    }
}