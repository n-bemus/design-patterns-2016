﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite_Pattern
{
    public class Individual : Memory
    {
        string theType;
        int theFileSize;

        public Individual(string type, int fileSize)
        {
            theType = type;
            theFileSize = fileSize;
        }

        public override void add(Memory file)
        {
            throw new NotImplementedException();
        }

        public override void remove(Memory file)
        {
            throw new NotImplementedException();
        }

        public override string Display(int depth)
        {
            String word = new String('-', depth) + theType + " " + theFileSize + " Kb file size " + System.Environment.NewLine;
            return word;
        }
    }
}
