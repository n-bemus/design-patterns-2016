﻿namespace Composite_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateFile = new System.Windows.Forms.Button();
            this.tbxMemoryStatus = new System.Windows.Forms.TextBox();
            this.btnCreateGame = new System.Windows.Forms.Button();
            this.btnCreateDoc = new System.Windows.Forms.Button();
            this.btnCreateMediaFile = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblMemoryStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCreateFile
            // 
            this.btnCreateFile.Location = new System.Drawing.Point(46, 45);
            this.btnCreateFile.Name = "btnCreateFile";
            this.btnCreateFile.Size = new System.Drawing.Size(95, 43);
            this.btnCreateFile.TabIndex = 0;
            this.btnCreateFile.Text = "Create File";
            this.btnCreateFile.UseVisualStyleBackColor = true;
            this.btnCreateFile.Click += new System.EventHandler(this.btnCreateFile_Click);
            // 
            // tbxMemoryStatus
            // 
            this.tbxMemoryStatus.Location = new System.Drawing.Point(210, 45);
            this.tbxMemoryStatus.Multiline = true;
            this.tbxMemoryStatus.Name = "tbxMemoryStatus";
            this.tbxMemoryStatus.Size = new System.Drawing.Size(293, 353);
            this.tbxMemoryStatus.TabIndex = 1;
            // 
            // btnCreateGame
            // 
            this.btnCreateGame.Location = new System.Drawing.Point(46, 122);
            this.btnCreateGame.Name = "btnCreateGame";
            this.btnCreateGame.Size = new System.Drawing.Size(95, 43);
            this.btnCreateGame.TabIndex = 2;
            this.btnCreateGame.Text = "Create Game File";
            this.btnCreateGame.UseVisualStyleBackColor = true;
            this.btnCreateGame.Click += new System.EventHandler(this.btnCreateGame_Click);
            // 
            // btnCreateDoc
            // 
            this.btnCreateDoc.Location = new System.Drawing.Point(46, 199);
            this.btnCreateDoc.Name = "btnCreateDoc";
            this.btnCreateDoc.Size = new System.Drawing.Size(95, 43);
            this.btnCreateDoc.TabIndex = 3;
            this.btnCreateDoc.Text = "Create Document";
            this.btnCreateDoc.UseVisualStyleBackColor = true;
            this.btnCreateDoc.Click += new System.EventHandler(this.btnCreateDoc_Click);
            // 
            // btnCreateMediaFile
            // 
            this.btnCreateMediaFile.Location = new System.Drawing.Point(46, 276);
            this.btnCreateMediaFile.Name = "btnCreateMediaFile";
            this.btnCreateMediaFile.Size = new System.Drawing.Size(95, 43);
            this.btnCreateMediaFile.TabIndex = 4;
            this.btnCreateMediaFile.Text = "Create Media File";
            this.btnCreateMediaFile.UseVisualStyleBackColor = true;
            this.btnCreateMediaFile.Click += new System.EventHandler(this.btnCreateMediaFile_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(46, 353);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(95, 43);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Reset Memory";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblMemoryStatus
            // 
            this.lblMemoryStatus.AutoSize = true;
            this.lblMemoryStatus.Location = new System.Drawing.Point(293, 25);
            this.lblMemoryStatus.Name = "lblMemoryStatus";
            this.lblMemoryStatus.Size = new System.Drawing.Size(139, 17);
            this.lblMemoryStatus.TabIndex = 6;
            this.lblMemoryStatus.Text = "Total Memory Used: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 420);
            this.Controls.Add(this.lblMemoryStatus);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCreateMediaFile);
            this.Controls.Add(this.btnCreateDoc);
            this.Controls.Add(this.btnCreateGame);
            this.Controls.Add(this.tbxMemoryStatus);
            this.Controls.Add(this.btnCreateFile);
            this.Name = "Form1";
            this.Text = "File Program";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreateFile;
        private System.Windows.Forms.TextBox tbxMemoryStatus;
        private System.Windows.Forms.Button btnCreateGame;
        private System.Windows.Forms.Button btnCreateDoc;
        private System.Windows.Forms.Button btnCreateMediaFile;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblMemoryStatus;
    }
}

