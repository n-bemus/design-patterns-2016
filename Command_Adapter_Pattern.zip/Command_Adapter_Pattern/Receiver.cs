﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Command_Adapter_Pattern
{
    public class Receiver
    {
        public Color fontcolor = System.Drawing.Color.Black;
        public void RandomColor()
        {
            Random random = new Random();
            int randomNumber = random.Next(0, 7);
            
            switch (randomNumber)
            {
                case 0:
                    fontcolor = System.Drawing.Color.Red;
                    break;
                case 1:
                    fontcolor = System.Drawing.Color.Orange;
                    break;
                case 2:
                    fontcolor = System.Drawing.Color.Yellow;
                    break;
                case 3:
                    fontcolor = System.Drawing.Color.Green;
                    break;
                case 4:
                    fontcolor = System.Drawing.Color.Blue;
                    break;
                case 5:
                    fontcolor = System.Drawing.Color.Pink;
                    break;
                default:
                    fontcolor = System.Drawing.Color.Black;
                    break;
            }
        }
    }
}
