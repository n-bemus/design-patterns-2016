﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Pattern
{
    public class ConcreteRandom : Command
    {
        private Receiver _receiver;

        public ConcreteRandom(Receiver receiver)
        {
            _receiver = receiver;
        }

        public void SetCommand(Receiver receiver)
        {
            this._receiver = receiver;
        }

        public override void Execute()
        {
            _receiver.RandomColor();
        }
    }
}
