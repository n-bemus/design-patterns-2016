﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Command_Adapter_Pattern
{
    public class Adapter : Target
    {
        public Font fonttype;
        public override void Request(int adaptee)
        {
            switch (adaptee)
            {
                case 0:
                    fonttype = new Font("Times New Roman", 12.0f);
                    break;
                case 1:
                    fonttype = new Font("Courier New", 12.0f);
                    break;
                case 2:
                    fonttype = new Font("Comic Sans", 12.0f);
                    break;
                case 3:
                    fonttype = new Font("Georgia", 12.0f);
                    break;
                case 4:
                    fonttype = new Font("Castellar", 12.0f);
                    break;
                case 5:
                    fonttype = new Font("Wingdings", 12.0f);
                    break;
                default:
                    fonttype = new Font("Calibri", 12.0f);
                    break;

            }
        }
    }
}
