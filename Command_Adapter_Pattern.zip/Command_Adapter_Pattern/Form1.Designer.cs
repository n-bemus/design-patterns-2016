﻿namespace Command_Adapter_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColor = new System.Windows.Forms.Button();
            this.tbxColor = new System.Windows.Forms.TextBox();
            this.btnChangeFont = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(59, 163);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(85, 49);
            this.btnColor.TabIndex = 0;
            this.btnColor.Text = "Colorize";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColorize_Click);
            // 
            // tbxColor
            // 
            this.tbxColor.Location = new System.Drawing.Point(113, 75);
            this.tbxColor.Name = "tbxColor";
            this.tbxColor.Size = new System.Drawing.Size(124, 22);
            this.tbxColor.TabIndex = 1;
            // 
            // btnChangeFont
            // 
            this.btnChangeFont.Location = new System.Drawing.Point(207, 163);
            this.btnChangeFont.Name = "btnChangeFont";
            this.btnChangeFont.Size = new System.Drawing.Size(85, 49);
            this.btnChangeFont.TabIndex = 2;
            this.btnChangeFont.Text = "Change Font Type";
            this.btnChangeFont.UseVisualStyleBackColor = true;
            this.btnChangeFont.Click += new System.EventHandler(this.btnChangeFont_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(345, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 153);
            this.label1.TabIndex = 3;
            this.label1.Text = "Key:\r\n\r\n\"0\" = Times New Roman\r\n\"1\" = Courier New\r\n\"2\" = Comic Sans\r\n\"3\" = Georgia" +
    "\r\n\"4\" = Casteller\r\n\"5\" = Wingdings\r\nanything else = Claibri";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 253);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnChangeFont);
            this.Controls.Add(this.tbxColor);
            this.Controls.Add(this.btnColor);
            this.Name = "Form1";
            this.Text = "Random Colorizer Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.TextBox tbxColor;
        private System.Windows.Forms.Button btnChangeFont;
        private System.Windows.Forms.Label label1;
    }
}

