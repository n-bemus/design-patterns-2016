﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command_Adapter_Pattern
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnColorize_Click(object sender, EventArgs e)
        {
            Receiver receiver = new Receiver();
            ConcreteRandom random = new ConcreteRandom(receiver);
            Invoker invoker = new Invoker();
            invoker.SetCommand(random);
            invoker.ExecuteCommand();
            tbxColor.ForeColor = receiver.fontcolor;
        }

        private void btnChangeFont_Click(object sender, EventArgs e)
        {
            Adaptee adaptee = new Adaptee();
            Adapter adapter = new Adapter();
            adapter.Request(Int32.Parse(tbxColor.Text));
            tbxColor.Font = adapter.fonttype;
        }
    }
}
