﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Power
    {
        private bool powerOn = false;

        public Power(){}

        public bool isPowerOn()
        {
            return powerOn;
        }

        public void PowerOn()
        {
            powerOn = true;
        }

        public void PowerDown()
        {
            powerOn = false;
        }
    }
}
