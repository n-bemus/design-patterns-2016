﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Movies
    {
        private bool isNetflixOn = false;

        public Movies(){}

        public bool isNetflixActive()
        {
            return isNetflixOn;
        }

        public void NetflixOn()
        {
            isNetflixOn = true;
        }

        public void NetflixOff()
        {
            isNetflixOn = false;
        }
    }
}
