﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Internet
    {
        private bool isInternetUse = false;

        public Internet(){}

        public bool isInternetUseHigh()
        {
            return isInternetUse;
        }

        public void InternetUseHigh()
        {
            isInternetUse = true;
        }

        public void InternetUseLow()
        {
            isInternetUse = false;
        }
    }
}
