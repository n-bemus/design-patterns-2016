﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Gaming
    {
        private bool isSteamOn = false;

        public Gaming(){}

        public bool isSteamActive()
        {
            return isSteamOn;
        }

        public void SteamOn()
        {
            isSteamOn = true;
        }

        public void SteamOff()
        {
            isSteamOn = false;
        }
    }
}
