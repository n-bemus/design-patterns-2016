﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Facade_Pattern
{
    public partial class Form1 : Form
    {
        Laptop remote;

        public Form1()
        {
            InitializeComponent();
            remote = new Laptop();
        }

        private void Facade_Load(object sender, EventArgs e)
        {

        }

        private void btnPower_Click(object sender, EventArgs e)
        {
            remote.Power();
            updateForm();
        }

        private void updateForm()
        {
            if (remote.power.isPowerOn())
            {
                lblPowerStatus.Text = "On";
            }
            else
            {
                lblPowerStatus.Text = "Off";
            }

            if (remote.gaming.isSteamActive())
            {
                lblSteamStatus.Text = "Active";
            }
            else
            {
                lblSteamStatus.Text = "Inactive";
            }

            if (remote.internet.isInternetUseHigh())
            {
                lblInternetUseStatus.Text = "High";
            }
            else
            {
                lblInternetUseStatus.Text = "Low";
            }

            if (remote.movies.isNetflixActive())
            {
                lblNetflixStatus.Text = "Active";
            }
            else
            {
                lblNetflixStatus.Text = "Inactive";
            }

            if (remote.homework.isIDEActive())
            {
                lblIDEStatus.Text = "Active";
            }
            else
            {
                lblIDEStatus.Text = "Inactive";
            }
        }

        private void btnGaming_Click(object sender, EventArgs e)
        {
            remote.Steam();
            updateForm();
        }

        private void btnMovies_Click(object sender, EventArgs e)
        {
            remote.Netflix();
            updateForm();
        }

        private void btnHomework_Click(object sender, EventArgs e)
        {
            remote.IDE();
            updateForm();
        }









    }
}
