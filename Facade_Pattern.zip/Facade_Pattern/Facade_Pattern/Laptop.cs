﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Laptop
    {

        public Power power = new Power();
        public Movies movies = new Movies();
        public Gaming gaming = new Gaming();
        public Homework homework = new Homework();
        public Internet internet = new Internet();

        public void Steam()
        {
            power.PowerOn();
            gaming.SteamOn();
            internet.InternetUseHigh();
            movies.NetflixOff();
            homework.IDEOff();
        }

        public void IDE()
        {
            power.PowerOn();
            gaming.SteamOff();
            internet.InternetUseLow();
            movies.NetflixOff();
            homework.IDEOn();
        }

        public void Netflix()
        {
            power.PowerOn();
            gaming.SteamOff();
            internet.InternetUseHigh();
            movies.NetflixOn();
            homework.IDEOff();
        }

        public void Power()
        {
            power.PowerDown();
            gaming.SteamOff();
            internet.InternetUseLow();
            movies.NetflixOff();
            homework.IDEOff();
        }

    }
}
