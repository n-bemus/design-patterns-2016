﻿namespace Facade_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHomework = new System.Windows.Forms.Button();
            this.btnGaming = new System.Windows.Forms.Button();
            this.btnMovies = new System.Windows.Forms.Button();
            this.lblSteam = new System.Windows.Forms.Label();
            this.lblSteamStatus = new System.Windows.Forms.Label();
            this.lblIDE = new System.Windows.Forms.Label();
            this.lblIDEStatus = new System.Windows.Forms.Label();
            this.lblPower = new System.Windows.Forms.Label();
            this.lblInternetUse = new System.Windows.Forms.Label();
            this.lblPowerStatus = new System.Windows.Forms.Label();
            this.lblInternetUseStatus = new System.Windows.Forms.Label();
            this.lblNetflix = new System.Windows.Forms.Label();
            this.lblNetflixStatus = new System.Windows.Forms.Label();
            this.btnPower = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnHomework
            // 
            this.btnHomework.Location = new System.Drawing.Point(32, 21);
            this.btnHomework.Name = "btnHomework";
            this.btnHomework.Size = new System.Drawing.Size(98, 47);
            this.btnHomework.TabIndex = 0;
            this.btnHomework.Text = "Homework";
            this.btnHomework.UseVisualStyleBackColor = true;
            this.btnHomework.Click += new System.EventHandler(this.btnHomework_Click);
            // 
            // btnGaming
            // 
            this.btnGaming.Location = new System.Drawing.Point(191, 21);
            this.btnGaming.Name = "btnGaming";
            this.btnGaming.Size = new System.Drawing.Size(98, 47);
            this.btnGaming.TabIndex = 1;
            this.btnGaming.Text = "Gaming";
            this.btnGaming.UseVisualStyleBackColor = true;
            this.btnGaming.Click += new System.EventHandler(this.btnGaming_Click);
            // 
            // btnMovies
            // 
            this.btnMovies.Location = new System.Drawing.Point(32, 94);
            this.btnMovies.Name = "btnMovies";
            this.btnMovies.Size = new System.Drawing.Size(98, 47);
            this.btnMovies.TabIndex = 2;
            this.btnMovies.Text = "Watch Movies";
            this.btnMovies.UseVisualStyleBackColor = true;
            this.btnMovies.Click += new System.EventHandler(this.btnMovies_Click);
            // 
            // lblSteam
            // 
            this.lblSteam.AutoSize = true;
            this.lblSteam.Location = new System.Drawing.Point(29, 173);
            this.lblSteam.Name = "lblSteam";
            this.lblSteam.Size = new System.Drawing.Size(52, 17);
            this.lblSteam.TabIndex = 4;
            this.lblSteam.Text = "Steam:";
            // 
            // lblSteamStatus
            // 
            this.lblSteamStatus.AutoSize = true;
            this.lblSteamStatus.Location = new System.Drawing.Point(102, 173);
            this.lblSteamStatus.Name = "lblSteamStatus";
            this.lblSteamStatus.Size = new System.Drawing.Size(56, 17);
            this.lblSteamStatus.TabIndex = 5;
            this.lblSteamStatus.Text = "Inactice";
            // 
            // lblIDE
            // 
            this.lblIDE.AutoSize = true;
            this.lblIDE.Location = new System.Drawing.Point(29, 228);
            this.lblIDE.Name = "lblIDE";
            this.lblIDE.Size = new System.Drawing.Size(38, 17);
            this.lblIDE.TabIndex = 6;
            this.lblIDE.Text = "IDE: ";
            // 
            // lblIDEStatus
            // 
            this.lblIDEStatus.AutoSize = true;
            this.lblIDEStatus.Location = new System.Drawing.Point(102, 228);
            this.lblIDEStatus.Name = "lblIDEStatus";
            this.lblIDEStatus.Size = new System.Drawing.Size(56, 17);
            this.lblIDEStatus.TabIndex = 7;
            this.lblIDEStatus.Text = "Inactive";
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Location = new System.Drawing.Point(188, 173);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(51, 17);
            this.lblPower.TabIndex = 8;
            this.lblPower.Text = "Power:";
            // 
            // lblInternetUse
            // 
            this.lblInternetUse.AutoSize = true;
            this.lblInternetUse.Location = new System.Drawing.Point(188, 228);
            this.lblInternetUse.Name = "lblInternetUse";
            this.lblInternetUse.Size = new System.Drawing.Size(89, 17);
            this.lblInternetUse.TabIndex = 9;
            this.lblInternetUse.Text = "Internet Use:";
            // 
            // lblPowerStatus
            // 
            this.lblPowerStatus.AutoSize = true;
            this.lblPowerStatus.Location = new System.Drawing.Point(300, 173);
            this.lblPowerStatus.Name = "lblPowerStatus";
            this.lblPowerStatus.Size = new System.Drawing.Size(27, 17);
            this.lblPowerStatus.TabIndex = 10;
            this.lblPowerStatus.Text = "Off";
            // 
            // lblInternetUseStatus
            // 
            this.lblInternetUseStatus.AutoSize = true;
            this.lblInternetUseStatus.Location = new System.Drawing.Point(300, 228);
            this.lblInternetUseStatus.Name = "lblInternetUseStatus";
            this.lblInternetUseStatus.Size = new System.Drawing.Size(33, 17);
            this.lblInternetUseStatus.TabIndex = 11;
            this.lblInternetUseStatus.Text = "Low";
            // 
            // lblNetflix
            // 
            this.lblNetflix.AutoSize = true;
            this.lblNetflix.Location = new System.Drawing.Point(29, 282);
            this.lblNetflix.Name = "lblNetflix";
            this.lblNetflix.Size = new System.Drawing.Size(50, 17);
            this.lblNetflix.TabIndex = 12;
            this.lblNetflix.Text = "Netflix:";
            // 
            // lblNetflixStatus
            // 
            this.lblNetflixStatus.AutoSize = true;
            this.lblNetflixStatus.Location = new System.Drawing.Point(102, 282);
            this.lblNetflixStatus.Name = "lblNetflixStatus";
            this.lblNetflixStatus.Size = new System.Drawing.Size(56, 17);
            this.lblNetflixStatus.TabIndex = 13;
            this.lblNetflixStatus.Text = "Inactive";
            // 
            // btnPower
            // 
            this.btnPower.Location = new System.Drawing.Point(191, 94);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(98, 47);
            this.btnPower.TabIndex = 14;
            this.btnPower.Text = "Power";
            this.btnPower.UseVisualStyleBackColor = true;
            this.btnPower.Click += new System.EventHandler(this.btnPower_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 352);
            this.Controls.Add(this.btnPower);
            this.Controls.Add(this.lblNetflixStatus);
            this.Controls.Add(this.lblNetflix);
            this.Controls.Add(this.lblInternetUseStatus);
            this.Controls.Add(this.lblPowerStatus);
            this.Controls.Add(this.lblInternetUse);
            this.Controls.Add(this.lblPower);
            this.Controls.Add(this.lblIDEStatus);
            this.Controls.Add(this.lblIDE);
            this.Controls.Add(this.lblSteamStatus);
            this.Controls.Add(this.lblSteam);
            this.Controls.Add(this.btnMovies);
            this.Controls.Add(this.btnGaming);
            this.Controls.Add(this.btnHomework);
            this.Name = "Form1";
            this.Text = "Laptop Remote";
            this.Load += new System.EventHandler(this.Facade_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHomework;
        private System.Windows.Forms.Button btnGaming;
        private System.Windows.Forms.Button btnMovies;
        private System.Windows.Forms.Label lblSteam;
        private System.Windows.Forms.Label lblSteamStatus;
        private System.Windows.Forms.Label lblIDE;
        private System.Windows.Forms.Label lblIDEStatus;
        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.Label lblInternetUse;
        private System.Windows.Forms.Label lblPowerStatus;
        private System.Windows.Forms.Label lblInternetUseStatus;
        private System.Windows.Forms.Label lblNetflix;
        private System.Windows.Forms.Label lblNetflixStatus;
        private System.Windows.Forms.Button btnPower;
    }
}

