﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Homework
    {
        private bool isIDEOn = false;

        public Homework(){}

        public bool isIDEActive()
        {
            return isIDEOn;
        }

        public void IDEOn()
        {
            isIDEOn = true;
        }

        public void IDEOff()
        {
            isIDEOn = false;
        }
    }
}
